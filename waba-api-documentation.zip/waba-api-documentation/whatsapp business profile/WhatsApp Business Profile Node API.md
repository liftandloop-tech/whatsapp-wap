

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| GET | [/{Version}/{WhatsApp-Business-Profile-ID}](#get-version-whatsapp-business-profile-id) |
| POST | [/{Version}/{WhatsApp-Business-Profile-ID}](#post-version-whatsapp-business-profile-id) |

<jumplink id="get-version-whatsapp-business-profile-id"></jumplink>
## GET /{Version}/{WhatsApp-Business-Profile-ID}

Get WhatsApp Business Profile Details

Retrieve comprehensive details about a WhatsApp Business Profile, including business information,
contact details, and profile configuration.


**Use Cases:**
- Retrieve business profile information and metadata
- Verify profile configuration and contact details
- Check profile status and business information
- Validate profile state before business operations


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


**Caching:**
Profile details can be cached for moderate periods, but business information may change
occasionally. Implement appropriate cache invalidation strategies.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WhatsApp-Business-Profile-ID | string | ✓ | Your WhatsApp Business Profile ID. This ID is provided when the profile is created and can be found in your WhatsApp Business Manager or through business management APIs. |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| fields | string |  | Comma-separated list of fields to include in the response. If not specified, default fields will be returned (id and any available profile fields). Available fields: id, account_name, description, email, about, address, vertical, websites, profile_picture_url, messaging_product |

### Responses

**200**

Successfully retrieved WhatsApp Business Profile details

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessProfileNode](#whatsappbusinessprofilenode)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: whatsapp_business_profile_id must be a valid numeric string",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to access this WhatsApp Business Profile",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - WhatsApp Business Profile ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Profile not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The requested fields are not available for this profile",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


<jumplink id="post-version-whatsapp-business-profile-id"></jumplink>
## POST /{Version}/{WhatsApp-Business-Profile-ID}

Update WhatsApp Business Profile

Update the WhatsApp Business Profile information such as business description, email, address,
and other profile details. This operation corresponds to the GraphWhatsAppBusinessProfilePost functionality.


**Use Cases:**
- Update business profile information and metadata
- Modify contact details and business description
- Change business vertical classification
- Update website URLs and profile picture
- Maintain current business profile information


**Profile Picture Upload:**
It is recommended to use the Resumable Upload API to obtain an upload ID, then use this
upload ID to obtain the picture handle for the `profile_picture_handle` field.


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WhatsApp-Business-Profile-ID | string | ✓ | Your WhatsApp Business Profile ID. This ID is provided when the profile is created and can be found in your WhatsApp Business Manager or through business management APIs. |

### Request Body (Required)

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessProfileUpdateRequest](#whatsappbusinessprofileupdaterequest)

### Responses

**200**

Successfully updated WhatsApp Business Profile

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessProfileUpdateResponse](#whatsappbusinessprofileupdateresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: messaging_product is required",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to update this WhatsApp Business Profile",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to modify this resource"
    }
}\n```

**404**

Not Found - WhatsApp Business Profile ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Profile not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The provided profile picture handle is invalid or expired",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinessprofilenode"></jumplink>
### WhatsAppBusinessProfileNode

WhatsApp Business Profile node details and configuration

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the WhatsApp Business Profile |
| account_name | string |  | Name of the business account |
| description | string |  | Business description text |
| email | string (email) |  | Contact email address of the business |
| about | string |  | About section text for the business profile |
| address | string |  | Physical address of the business |
| vertical | [WhatsAppBusinessVertical](#whatsappbusinessvertical) |  |  |
| websites | array of string (uri) |  | List of website URLs associated with the business |
| profile_picture_url | string (uri) |  | URL of the business profile picture |
| profile_picture_handle | string |  | Handle of the profile picture for upload operations |
| messaging_product | "whatsapp" |  | The messaging service used |

<jumplink id="whatsappbusinessprofileupdaterequest"></jumplink>
### WhatsAppBusinessProfileUpdateRequest

Request payload for updating WhatsApp Business Profile information

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| messaging_product | "whatsapp" | ✓ | The messaging service used for the request |
| account_name | string |  | Name of the business account |
| description | string |  | Business description text |
| email | string (email) |  | Contact email address of the business |
| about | string |  | About section text for the business profile |
| address | string |  | Physical address of the business |
| vertical | [WhatsAppBusinessVertical](#whatsappbusinessvertical) |  |  |
| websites | array of string (uri) |  | List of website URLs associated with the business |
| profile_picture_handle | string |  | Handle of the profile picture generated from Resumable Upload API |

<jumplink id="whatsappbusinessprofileupdateresponse"></jumplink>
### WhatsAppBusinessProfileUpdateResponse

Response from updating WhatsApp Business Profile

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string |  | WhatsApp Business Profile ID that was updated |
| success | boolean |  | Indicates if the update was successful |

<jumplink id="whatsappbusinessvertical"></jumplink>
### WhatsAppBusinessVertical

Industry vertical classification for the business

**Type**: string

**Enum Values**: "UNDEFINED", "OTHER", "AUTO", "BEAUTY", "APPAREL", "EDU", "ENTERTAIN", "EVENT_PLAN", "FINANCE", "GROCERY", "GOVT", "HOTEL", "HEALTH", "NONPROFIT", "PROF_SERVICES", "RETAIL", "TRAVEL", "RESTAURANT", "NOT_A_BIZ"

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-1) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-error-1"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
