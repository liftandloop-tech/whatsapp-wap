

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| POST | [/{Version}/{Pre-Verified-Phone-Number-ID}/verify_code](#post-version-pre-verified-phone-number-id-verify-code) |

<jumplink id="post-version-pre-verified-phone-number-id-verify-code"></jumplink>
## POST /{Version}/{Pre-Verified-Phone-Number-ID}/verify_code

Verify OTP Code for Pre-Verified Phone Number

Verify the OTP code received for a pre-verified phone number to complete the
verification process. This endpoint validates the code and updates the verification
status of the phone number.


**Use Cases:**
- Complete phone number verification during WhatsApp Business onboarding
- Verify ownership of phone numbers for business messaging
- Enable phone numbers for WhatsApp Business API usage


**Rate Limiting:**
This endpoint has specific rate limits to prevent abuse:
- 125 requests per hour for business use cases
- Standard Graph API rate limits also apply


**Code Validation:**
- Codes are time-sensitive and expire after a set period
- Each code can only be used once
- Invalid or expired codes will result in verification failure


**Error Handling:**
- Invalid codes return 400 Bad Request
- Expired codes return 422 Unprocessable Entity
- Rate limit exceeded returns 429 Too Many Requests


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| Pre-Verified-Phone-Number-ID | string | ✓ | Your Pre-Verified Phone Number ID. This ID is provided when you create the pre-verified phone number and can be found in your WhatsApp Business Manager or through phone number APIs. |

### Request Body (Required)

Verification code details

**Content Type**: `application/json`

**Schema**: [VerifyCodeRequest](#verifycoderequest)

### Responses

**200**

Successfully verified the OTP code

**Content Type**: `application/json`

**Schema**: [VerifyCodeResponse](#verifycoderesponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to access this Pre-Verified Phone Number",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - Pre-Verified Phone Number ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Pre-Verified Phone Number not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Code is invalid, expired, or already used

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="verifycoderequest"></jumplink>
### VerifyCodeRequest

Request payload for verifying OTP code

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| code | string | ✓ | The numeric verification code received via SMS or voice call. This code is provided after calling the request_code endpoint. |

<jumplink id="verifycoderesponse"></jumplink>
### VerifyCodeResponse

Response indicating successful code verification

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| success | boolean | ✓ | Indicates whether the code verification was successful |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-1) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-error-1"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
