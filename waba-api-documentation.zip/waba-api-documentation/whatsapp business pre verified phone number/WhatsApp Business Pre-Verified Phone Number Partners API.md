

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| GET | [/{Version}/{Pre-Verified-Phone-Number-ID}/partners](#get-version-pre-verified-phone-number-id-partners) |

<jumplink id="get-version-pre-verified-phone-number-id-partners"></jumplink>
## GET /{Version}/{Pre-Verified-Phone-Number-ID}/partners

Get Pre-Verified Phone Number Partners

Retrieve the list of partner businesses that have been granted access to a specific
WhatsApp Business Pre-Verified Phone Number.


**Use Cases:**
- Monitor partner business relationships and access permissions
- Verify which businesses have access to shared pre-verified phone numbers
- Retrieve partner business information for operational purposes
- Validate partnership configurations before business operations


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


**Caching:**
Partner information can be cached for moderate periods, but partnership relationships
may change. Implement appropriate cache invalidation strategies.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| Pre-Verified-Phone-Number-ID | string | ✓ | Your Pre-Verified Phone Number ID. This ID is provided when the pre-verified phone number is created and can be found in your WhatsApp Business Account management interface. |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| fields | string |  | Comma-separated list of fields to include in the response. If not specified, default fields will be returned (id, name). Available fields: id, name, created_time, updated_time, verification_status, primary_page, timezone_id, two_factor_type |
| limit | integer [min: 1, max: 100] |  | Maximum number of partner businesses to return per page. Default is 25, maximum is 100. |
| after | string |  | Cursor for pagination. Use the 'after' cursor from a previous response to get the next page. |
| before | string |  | Cursor for pagination. Use the 'before' cursor from a previous response to get the previous page. |

### Responses

**200**

Successfully retrieved partner businesses for the pre-verified phone number

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessPreVerifiedPhoneNumberPartnersResponse](#whatsappbusinesspreverifiedphonenumberpartnersresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: pre_verified_phone_number_id must be a valid numeric string",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to access this Pre-Verified Phone Number",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - Pre-Verified Phone Number ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Pre-Verified Phone Number not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The requested fields are not available for this pre-verified phone number",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinesspreverifiedphonenumberpartnersresponse"></jumplink>
### WhatsAppBusinessPreVerifiedPhoneNumberPartnersResponse

Response containing partner businesses for a pre-verified phone number

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| data | array of [BusinessPartner](#businesspartner) | ✓ | List of partner businesses with access to the pre-verified phone number |
| paging | [CursorPaging](#cursorpaging) |  |  |

<jumplink id="businesspartner"></jumplink>
### BusinessPartner

Business entity that has partner access to the pre-verified phone number

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the partner business |
| name | string | ✓ | Name of the partner business |
| created_time | string (date-time) |  | ISO 8601 timestamp when the business was created |
| updated_time | string (date-time) |  | ISO 8601 timestamp when the business was last updated |
| verification_status | One of "not_verified", "pending", "verified" |  | Business verification status |
| primary_page | string |  | Primary Facebook Page ID associated with the business |
| timezone_id | integer |  | Timezone identifier for the business location |
| two_factor_type | One of "none", "admin_required" |  | Two-factor authentication method configured for the business |

<jumplink id="cursorpaging"></jumplink>
### CursorPaging

Cursor-based pagination information

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| cursors | [Cursors](#object-cursors-1) |  |  |
| next | string |  | Graph API endpoint URL for the next page of results |
| previous | string |  | Graph API endpoint URL for the previous page of results |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-2) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-cursors-1"></jumplink>
### Cursors

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| before | string |  | Cursor pointing to the start of the page of data that has been returned |
| after | string |  | Cursor pointing to the end of the page of data that has been returned |

<jumplink id="object-error-2"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
