

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| POST | [/{Version}/{Phone-Number-ID}/register](#post-version-phone-number-id-register) |

<jumplink id="post-version-phone-number-id-register"></jumplink>
## POST /{Version}/{Phone-Number-ID}/register

Register WhatsApp Business Phone Number

Register a WhatsApp Business phone number for messaging capabilities and enable
two-step verification. This is a required step before sending messages through
the WhatsApp Business Cloud API.


**Registration Process:**
1. Phone number must be in UNVERIFIED status
2. Provide a 6-digit PIN for two-step verification
3. Optionally provide backup data for account migration
4. Registration activates messaging capabilities


**Migration Support:**
For migrating from on-premises WhatsApp Business API, include backup data
with password and encrypted account information.


**Rate Limiting:**
Registration attempts are rate-limited to prevent abuse. Standard Graph API
rate limits apply with additional restrictions for registration endpoints.


**Security Requirements:**
- Two-step verification is mandatory for all registered numbers
- PIN must be securely stored and managed by the business
- Registration enables webhook delivery and message sending capabilities


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| Phone-Number-ID | string | ✓ | The ID of the phone number to register. This ID is provided when the phone number is added to your WhatsApp Business Account and can be found in WhatsApp Manager. |

### Request Body (Required)

Registration request payload with PIN and optional migration data

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessPhoneNumberRegistrationRequest](#whatsappbusinessphonenumberregistrationrequest)

### Responses

**200**

Successfully registered WhatsApp Business phone number

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessPhoneNumberRegistrationResponse](#whatsappbusinessphonenumberregistrationresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid PIN format. PIN must be exactly 6 digits",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to register this phone number",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - Phone number ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Phone number not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Phone number cannot be registered in current state

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Phone number is already registered or in invalid state for registration",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Registration rate limit exceeded",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred during registration. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinessphonenumberregistrationrequest"></jumplink>
### WhatsAppBusinessPhoneNumberRegistrationRequest

Request payload for registering a WhatsApp Business phone number

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| messaging_product | "whatsapp" | ✓ | Must be 'whatsapp' to indicate WhatsApp Business messaging product |
| pin | string | ✓ | 6-digit PIN for two-step verification setup |
| backup | [WhatsAppBusinessAccountBackup](#whatsappbusinessaccountbackup) |  |  |
| data_localization_region | [WhatsAppDataLocalizationRegion](#whatsappdatalocalizationregion) |  |  |
| meta_store_retention_minutes | integer [min: 60, max: 60] |  | Message retention period in minutes (deprecated in v21+) |

<jumplink id="whatsappbusinessaccountbackup"></jumplink>
### WhatsAppBusinessAccountBackup

Backup data for migrating existing WhatsApp Business accounts

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| password | string |  | Backup password for account migration |
| data | string |  | Encrypted backup data for account migration |

<jumplink id="whatsappdatalocalizationregion"></jumplink>
### WhatsAppDataLocalizationRegion

Data localization region for message storage (deprecated in v21+)

**Type**: string

**Enum Values**: "AE", "AU", "BH", "BR", "CA", "CH", "DE", "GB", "ID", "IN", "JP", "KR", "SG", "ZA"

<jumplink id="whatsappbusinessphonenumberregistrationresponse"></jumplink>
### WhatsAppBusinessPhoneNumberRegistrationResponse

Response from phone number registration request

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| success | boolean | ✓ | Indicates whether the registration was successful |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-1) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-error-1"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
