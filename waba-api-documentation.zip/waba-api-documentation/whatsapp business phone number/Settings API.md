

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com |  |

## APIs

| Method | Endpoint |
|--------|----------|
| GET | [/{Version}/{Phone-Number-ID}/settings](#get-version-phone-number-id-settings) |
| POST | [/{Version}/{Phone-Number-ID}/settings](#post-version-phone-number-id-settings) |

<jumplink id="get-version-phone-number-id-settings"></jumplink>
## GET /{Version}/{Phone-Number-ID}/settings

Get phone number settings

Retrieve current settings for a WhatsApp Business phone number.
Returns calling settings, payload encryption settings, and data
storage configurations.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |
| Content-Type | One of "application/json", "application/x-www-form-urlencoded", "multipart/form-data" | ✓ | Media type of the request body |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ |  |
| Phone-Number-ID | string | ✓ |  |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| include_sip_credentials | boolean |  | Include SIP credentials in the response (requires additional permissions) |

### Responses

**200**

Current phone number settings retrieved successfully

**Content Type**: `application/json`

**Schema**: [PhoneNumberSettingsResponse](#phonenumbersettingsresponse)

**400**

Bad Request - Invalid request parameters

**Content Type**: `application/json`

**Schema**: [ErrorResponse](#errorresponse)

**403**

Forbidden - Template not approved or insufficient permissions

**Content Type**: `application/json`

**Schema**: [ErrorResponse](#errorresponse)


<jumplink id="post-version-phone-number-id-settings"></jumplink>
## POST /{Version}/{Phone-Number-ID}/settings

Update phone number settings

Update various settings for a WhatsApp Business phone number.
You can configure calling settings, user identity change settings,
payload encryption, and data storage configurations.
Only one feature setting can be specified per request.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |
| Content-Type | One of "application/json", "application/x-www-form-urlencoded", "multipart/form-data" | ✓ | Media type of the request body |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ |  |
| Phone-Number-ID | string | ✓ |  |

### Request Body (Optional)

**Content Type**: `application/json`

**Schema**: Must be one of: [CallingSettingsRequest](#callingsettingsrequest), [UserIdentityChangeSettingsRequest](#useridentitychangesettingsrequest), [PayloadEncryptionSettingsRequest](#payloadencryptionsettingsrequest), [StorageConfigurationSettingsRequest](#storageconfigurationsettingsrequest)

### Responses

**200**

Settings updated successfully

**Content Type**: `application/json`

**Schema**: object

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| success | boolean |  |  |

**400**

Bad Request - Invalid request parameters

**Content Type**: `application/json`

**Schema**: [ErrorResponse](#errorresponse)

**403**

Forbidden - Template not approved or insufficient permissions

**Content Type**: `application/json`

**Schema**: [ErrorResponse](#errorresponse)


# Components

## Schemas

<jumplink id="callingsettingsrequest"></jumplink>
### CallingSettingsRequest

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| calling | [CallingSettings](#callingsettings) | ✓ |  |

<jumplink id="callingsettings"></jumplink>
### CallingSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Enable or disable calling feature |
| call_icon_visibility | One of "visible", "hidden" |  | Control visibility of the call icon |
| video | [VideoSettings](#videosettings) |  |  |
| sip | [SipSettings](#sipsettings) |  |  |
| srtp_key_exchange_protocol | One of "DTLS-SRTP", "SDES-SRTP" |  | SRTP key exchange protocol |

<jumplink id="videosettings"></jumplink>
### VideoSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Enable or disable video calling |

<jumplink id="sipsettings"></jumplink>
### SipSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Enable or disable SIP calling |

<jumplink id="useridentitychangesettingsrequest"></jumplink>
### UserIdentityChangeSettingsRequest

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| user_identity_change | [UserIdentityChangeSettings](#useridentitychangesettings) | ✓ |  |

<jumplink id="useridentitychangesettings"></jumplink>
### UserIdentityChangeSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| enabled | boolean | ✓ | Enable or disable user identity change notifications |

<jumplink id="payloadencryptionsettingsrequest"></jumplink>
### PayloadEncryptionSettingsRequest

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| payload_encryption | [PayloadEncryptionSettings](#payloadencryptionsettings) | ✓ |  |

<jumplink id="payloadencryptionsettings"></jumplink>
### PayloadEncryptionSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Enable or disable payload encryption |
| client_encryption_key | string |  | Base64-encoded public key for payload encryption (required when enabling encryption) |

<jumplink id="storageconfigurationsettingsrequest"></jumplink>
### StorageConfigurationSettingsRequest

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| storage_configuration | [StorageConfigurationSettings](#storageconfigurationsettings) | ✓ |  |

<jumplink id="storageconfigurationsettings"></jumplink>
### StorageConfigurationSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| enabled | boolean | ✓ | Enable or disable custom storage configuration |
| region | string |  | Data storage region |

<jumplink id="phonenumbersettingsresponse"></jumplink>
### PhoneNumberSettingsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| calling | [CallingSettingsResponse](#callingsettingsresponse) | ✓ |  |
| payload_encryption | [PayloadEncryptionSettingsResponse](#payloadencryptionsettingsresponse) |  |  |
| storage_configuration | [StorageConfigurationSettingsResponse](#storageconfigurationsettingsresponse) | ✓ |  |

<jumplink id="callingsettingsresponse"></jumplink>
### CallingSettingsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Current calling feature status |
| call_icon_visibility | One of "visible", "hidden" | ✓ | Current call icon visibility setting |
| ip_addresses | [Ip_addresses](#object-ip_addresses-1) | ✓ |  |
| callback_permission_status | One of "enabled", "disabled" | ✓ | Callback permission status |
| srtp_key_exchange_protocol | One of "DTLS-SRTP", "SDES-SRTP" |  | SRTP key exchange protocol (optional) |
| call_hours | [CallHoursSettings](#callhourssettings) |  |  |
| call_icons | [CallIconsSettings](#calliconssettings) |  |  |
| sip | [SipSettingsResponse](#sipsettingsresponse) |  |  |
| video | [VideoSettingsResponse](#videosettingsresponse) |  |  |
| audio | [AudioSettingsResponse](#audiosettingsresponse) |  |  |
| restrictions | [CallingRestrictionsResponse](#callingrestrictionsresponse) |  |  |

<jumplink id="callhourssettings"></jumplink>
### CallHoursSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Call hours feature status |
| timezone | string |  | Timezone for call hours |
| day_of_week_start | string |  | Start day of the week |

<jumplink id="calliconssettings"></jumplink>
### CallIconsSettings

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| restrict_to_user_countries | array of string |  | List of countries where call icons are restricted |

<jumplink id="sipsettingsresponse"></jumplink>
### SipSettingsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | SIP calling status |
| servers | array of [SipServerInfo](#sipserverinfo) |  | SIP server configuration |

<jumplink id="sipserverinfo"></jumplink>
### SipServerInfo

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| app_id | string | ✓ | Application ID for SIP server |
| hostname | string | ✓ | SIP server hostname |
| port | integer |  | SIP server port (optional) |
| password | string |  | SIP password (only included when include_sip_credentials=true) |

<jumplink id="videosettingsresponse"></jumplink>
### VideoSettingsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Video calling status |

<jumplink id="audiosettingsresponse"></jumplink>
### AudioSettingsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" |  | Audio calling status |

<jumplink id="callingrestrictionsresponse"></jumplink>
### CallingRestrictionsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| restrictions | array of [Restrictions](#object-restrictions-2) |  |  |

<jumplink id="payloadencryptionsettingsresponse"></jumplink>
### PayloadEncryptionSettingsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "enabled", "disabled" | ✓ | Payload encryption status |
| client_encryption_key_fingerprint | string |  | Client encryption key fingerprint (when encryption is enabled) |
| cloud_encryption_key | string |  | Cloud encryption key (when encryption is enabled) |

<jumplink id="storageconfigurationsettingsresponse"></jumplink>
### StorageConfigurationSettingsResponse

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| status | One of "default", "in_country_storage_enabled" | ✓ | Data storage configuration status |
| data_localization_region | string |  | Data localization region (when in-country storage is enabled) |

## Inline Object Definitions

<jumplink id="object-ip_addresses-1"></jumplink>
### Ip_addresses

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| default | array of string | ✓ | Default IP addresses for calling |

<jumplink id="object-restrictions-2"></jumplink>
### Restrictions

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| type | string |  | Type of restriction |
| expiration | integer (int64) |  | Expiration timestamp for the restriction |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
