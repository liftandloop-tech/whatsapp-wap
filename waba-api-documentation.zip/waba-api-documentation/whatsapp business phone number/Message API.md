

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com |  |

## APIs

| Method | Endpoint |
|--------|----------|
| POST | [/{Version}/{Phone-Number-ID}/messages](#post-version-phone-number-id-messages) |

<jumplink id="post-version-phone-number-id-messages"></jumplink>
## POST /{Version}/{Phone-Number-ID}/messages

Send Message.

Send Message.

### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |
| Content-Type | One of "application/json", "application/x-www-form-urlencoded", "multipart/form-data" | ✓ | Media type of the request body |

### Request Body (Optional)

**Content Type**: `application/json`

**Schema**: [Message](#message)

### Responses

**200**

Send Test Message / Send Text Message / Send Reply to Text Message / Send Reply with Reaction Message / Send Image Message by ID / Send Reply to Image Message by ID / Send Image Message by URL / Send Reply to Image Message by URL / Send Audio Message by ID / Send Reply to Audio Message by ID / Send Audio Message By URL / Send Reply to Audio Message by URL / Send Document Message by ID / Send Reply to Document Message by ID / Send Document Message by URL / Send Reply to Document Message by URL / Send Sticker Message By ID / Send Reply to Sticker Message by ID / Send Sticker Message By URL / Send Reply to Sticker Message by URL / Send Video Message By ID / Send Reply to Video Message by ID / Send Video Message By URL / Send Reply to Video Message by URL / Send Contact Message / Send Reply to Contact Message / Send Location Messages / Send Reply to Location Message / Send Message Template Text / Send Message Template Media / Send Interactive Message Template / Send List Message / Send Reply to List Message / Send Reply Button / Send Single Product Message / Example response / Example response / Send Draft Flow by Name / Send Draft Flow by ID / Send Published Flow by Name / Send Published Flow by ID / Send Flow Template Message / Send typing indicator and read receipt / Send Sample Text message / Send Sample Shipping Confirmation Template / Send Sample Issue Resolution Template

**Content Type**: `application/json`

**Schema**: [MessageResponsePayload](#messageresponsepayload)


# Components

## Schemas

<jumplink id="basemessageproperties"></jumplink>
### BaseMessageProperties

Common properties shared by all message types

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| messaging_product | string | ✓ |  |
| recipient_type | One of "individual", "group" | ✓ | The type of recipient. |
| to | string | ✓ | The recipient's phone number for individual messages, and group-id for group message. |
| type | string | ✓ | The type of message |
| context | [MessageContext](#messagecontext) |  |  |

<jumplink id="messagecontext"></jumplink>
### MessageContext

Context information for replying to a message

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message_id | string |  | The ID of the message to which this message is a reply. |

<jumplink id="mediaobject"></jumplink>
### MediaObject

A media object. Either `id` or `link` is required.

**Type**: object

<jumplink id="message"></jumplink>
### Message

<jumplink id="textmessage"></jumplink>
### TextMessage

<jumplink id="audiomessage"></jumplink>
### AudioMessage

<jumplink id="videomessage"></jumplink>
### VideoMessage

<jumplink id="documentmessage"></jumplink>
### DocumentMessage

<jumplink id="imagemessage"></jumplink>
### ImageMessage

<jumplink id="locationmessage"></jumplink>
### LocationMessage

<jumplink id="stickermessage"></jumplink>
### StickerMessage

<jumplink id="reactionmessage"></jumplink>
### ReactionMessage

<jumplink id="interactivemessage"></jumplink>
### InteractiveMessage

<jumplink id="interactiveobject"></jumplink>
### InteractiveObject

An object containing the content for an interactive message.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| type | One of "button", "call_permission_request", "catalog_message", "list", "product", "product_list", "flow" | ✓ | The type of interactive message to send. |
| header | [HeaderObject](#headerobject) |  |  |
| body | [BodyObject](#bodyobject) |  |  |
| footer | [FooterObject](#footerobject) |  |  |
| action | [ActionObject](#actionobject) | ✓ |  |

<jumplink id="headerobject"></jumplink>
### HeaderObject

Header content displayed on top of a message. Required for 'product_list' type. Cannot be set for 'product' type.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| type | One of "text", "video", "image", "document" | ✓ | The header type. |
| text | string |  | Text for the header. Required if 'type' is 'text'. Emojis supported, no markdown. |
| sub_text | string |  | Optional sub-text for the header. Emojis supported, no markdown. |
| document | [MediaObject](#mediaobject) |  | Contains the media object for this document. Required if 'type' is 'document'. |
| image | [MediaObject](#mediaobject) |  | Contains the media object for this image. Required if 'type' is 'image'. |
| video | [MediaObject](#mediaobject) |  | Contains the media object for this video. Required if 'type' is 'video'. |

<jumplink id="bodyobject"></jumplink>
### BodyObject

An object with the body of the message. Optional for 'product' type, required for other interactive message types.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| text | string | ✓ | The content of the message body. Emojis and markdown are supported. |

<jumplink id="footerobject"></jumplink>
### FooterObject

An object with the footer of the message. Optional.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| text | string | ✓ | The footer content. Emojis, markdown, and links are supported. |

<jumplink id="actionobject"></jumplink>
### ActionObject

Action you want the user to perform after reading the message. Its structure varies by interactive message type.

**Type**: object

<jumplink id="sectionobject"></jumplink>
### SectionObject

A section object, used in List Messages and Multi-Product Messages.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| title | string |  | Title of the section. Required if the message has more than one section. Max 24 characters. |
| product_items | array of [Product_items](#object-product_items-1) |  | Array of product objects. |
| rows | array of [Rows](#object-rows-2) |  | Contains a list of rows. |

<jumplink id="templatemessage"></jumplink>
### TemplateMessage

<jumplink id="contactsmessage"></jumplink>
### ContactsMessage

<jumplink id="contactobject"></jumplink>
### ContactObject

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| addresses | array of [AddressObject](#addressobject) |  | Full contact address(es) |
| birthday | string (date) |  | Date of birth (YYYY-MM-DD format) |
| emails | array of [EmailObject](#emailobject) |  | Contact email address(es) |
| name | [NameObject](#nameobject) |  | Contact name object |
| org | [OrganizationObject](#organizationobject) |  | Contact organization information |
| phones | array of [PhoneObject](#phoneobject) |  | Contact phone number(s) |
| urls | array of [UrlObject](#urlobject) |  | Contact URL(s) |

**Additional Properties**: Not allowed

<jumplink id="addressobject"></jumplink>
### AddressObject

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| city | string |  | City name |
| country | string |  | Full country name |
| country_code | string |  | Two-letter ISO country code |
| state | string |  | State abbreviation |
| street | string |  | Street address |
| type | One of "HOME", "WORK" |  | Address type |
| zip | string |  | ZIP code |

**Additional Properties**: Not allowed

<jumplink id="emailobject"></jumplink>
### EmailObject

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| email | string (email) | ✓ | Email address |
| type | One of "HOME", "WORK" |  | Email type |

**Additional Properties**: Not allowed

<jumplink id="nameobject"></jumplink>
### NameObject

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| first_name | string |  | First name |
| formatted_name | string |  | Formatted full name |
| last_name | string |  | Last name |
| middle_name | string |  | Middle name |
| prefix | string |  | Name prefix |
| suffix | string |  | Name suffix |

**Additional Properties**: Not allowed

<jumplink id="organizationobject"></jumplink>
### OrganizationObject

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| company | string |  | Company name |
| department | string |  | Department name |
| title | string |  | Job title |

**Additional Properties**: Not allowed

<jumplink id="phoneobject"></jumplink>
### PhoneObject

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| phone | string | ✓ | Phone number |
| type | One of "HOME", "WORK" |  | Phone type |
| wa_id | string |  | WhatsApp ID |

**Additional Properties**: Not allowed

<jumplink id="urlobject"></jumplink>
### UrlObject

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| type | One of "HOME", "WORK" |  | URL type |
| url | string (uri) | ✓ | URL |

**Additional Properties**: Not allowed

<jumplink id="messageresponsepayload"></jumplink>
### MessageResponsePayload

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| contacts | array of [Contacts](#object-contacts-3) |  |  |
| messages | array of [Messages](#object-messages-4) |  |  |
| messaging_product | string |  |  |

<jumplink id="markmessagerequestpayload"></jumplink>
### MarkMessageRequestPayload

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message_id | string | ✓ |  |
| messaging_product | string | ✓ |  |
| status | string | ✓ |  |

<jumplink id="markmessageresponsepayload"></jumplink>
### MarkMessageResponsePayload

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| success | boolean |  |  |

## Inline Object Definitions

<jumplink id="object-product_items-1"></jumplink>
### Product_items

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| product_retailer_id | string | ✓ | Unique identifier of the product in a catalog. |

<jumplink id="object-rows-2"></jumplink>
### Rows

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique row identifier. |
| title | string | ✓ | Row title. |
| description | string |  | Optional row description. |

<jumplink id="object-contacts-3"></jumplink>
### Contacts

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| input | string |  |  |
| wa_id | string |  |  |

<jumplink id="object-messages-4"></jumplink>
### Messages

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string |  |  |
| message_status | One of "accepted", "held_for_quality_assessment", "paused" |  | The status of a WhatsApp message: - `accepted`: The message has been accepted by WhatsApp and is being processed - `held_for_quality_assessment`: The message is being held for quality assessment before delivery - `paused`: The message delivery has been paused |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
