

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com |  |

## APIs

| Method | Endpoint |
|--------|----------|
| POST | [/{Version}/{Phone-Number-ID}/marketing_messages](#post-version-phone-number-id-marketing-messages) |

<jumplink id="post-version-phone-number-id-marketing-messages"></jumplink>
## POST /{Version}/{Phone-Number-ID}/marketing_messages

Send Marketing Template Message

Send marketing template messages using pre-approved templates. Supports optional product policy controls and message activity sharing settings.

### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |
| Content-Type | One of "application/json", "application/x-www-form-urlencoded", "multipart/form-data" | ✓ | Media type of the request body |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | WhatsApp API version (e.g., v20.0) |
| Phone-Number-ID | string | ✓ | WhatsApp Business Phone Number ID |

### Request Body (Required)

**Content Type**: `application/json`

**Schema**: [MarketingMessageRequestPayload](#marketingmessagerequestpayload)

### Responses

**200**

Marketing message sent successfully

**Content Type**: `application/json`

**Schema**: [MarketingMessageResponsePayload](#marketingmessageresponsepayload)

**400**

Bad Request - Invalid request parameters

**Content Type**: `application/json`

**Schema**: [ErrorResponse](#errorresponse)

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [ErrorResponse](#errorresponse)

**403**

Forbidden - Template not approved or insufficient permissions

**Content Type**: `application/json`

**Schema**: [ErrorResponse](#errorresponse)


# Components

## Schemas

<jumplink id="marketingmessagerequestpayload"></jumplink>
### MarketingMessageRequestPayload

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| messaging_product | "whatsapp" | ✓ | Messaging service used. Must be "whatsapp" |
| recipient_type | "individual" | ✓ | Type of recipient. Must be "individual" |
| to | string | ✓ | WhatsApp ID or phone number of the message recipient |
| type | "template" | ✓ | Type of message. Must be "template" for marketing messages |
| template | [Template](#object-template-1) | ✓ |  |
| product_policy | One of "CLOUD_API_FALLBACK", "STRICT" |  | Optional product policy setting |
| message_activity_sharing | boolean |  | Optional flag to control message activity sharing |

**Additional Properties**: Not allowed

<jumplink id="marketingmessageresponsepayload"></jumplink>
### MarketingMessageResponsePayload

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| contacts | array of [Contacts](#object-contacts-2) |  |  |
| messages | array of [Messages](#object-messages-3) |  |  |
| messaging_product | string |  |  |

## Inline Object Definitions

<jumplink id="object-template-1"></jumplink>
### Template

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| name | string | ✓ | Name of the template. |
| language | [LanguageObject](#languageobject) | ✓ | Contains a `language` object. Specifies the language the template may be rendered in |
| components | array of [TemplateComponent](#templatecomponent) |  | Array of `components` objects containing the parameters of the message. |

<jumplink id="object-contacts-2"></jumplink>
### Contacts

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| input | string |  |  |
| wa_id | string |  |  |

<jumplink id="object-messages-3"></jumplink>
### Messages

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string |  |  |
| message_status | One of "accepted", "held_for_quality_assessment", "paused" |  | The status of a WhatsApp message: - `accepted`: The message has been accepted by WhatsApp and is being processed - `held_for_quality_assessment`: The message is being held for quality assessment before delivery - `paused`: The message delivery has been paused |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
