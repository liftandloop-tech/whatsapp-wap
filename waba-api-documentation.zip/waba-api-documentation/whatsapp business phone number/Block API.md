

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com |  |

## APIs

| Method | Endpoint |
|--------|----------|
| DELETE | [/{Version}/{Phone-Number-ID}/block_users](#delete-version-phone-number-id-block-users) |
| GET | [/{Version}/{Phone-Number-ID}/block_users](#get-version-phone-number-id-block-users) |
| POST | [/{Version}/{Phone-Number-ID}/block_users](#post-version-phone-number-id-block-users) |

<jumplink id="delete-version-phone-number-id-block-users"></jumplink>
## DELETE /{Version}/{Phone-Number-ID}/block_users

Unblock user(s)

- Guide: [Block Users](https://developers.facebook.com/docs/business-messaging/whatsapp/block-users)\n    \n- Endpoint reference: [DELETE WhatsApp Buiness Phone Number &gt; block_users](https://developers.facebook.com/docs/graph-api/reference/whats-app-business-account-to-number-current-status/block_users/#Deleting)

### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |
| Content-Type | One of "application/json", "application/x-www-form-urlencoded", "multipart/form-data" | ✓ | Media type of the request body |

### Request Body (Optional)

**Content Type**: `application/json`

**Schema**: object

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| block_users | array of [Block_users](#object-block_users-1) |  |  |
| messaging_product | string |  |  |

### Responses

**200**

Unblock user(s)

**Content Type**: `application/json`

**Schema**: [UnblockUsersData](#unblockusersdata)


<jumplink id="get-version-phone-number-id-block-users"></jumplink>
## GET /{Version}/{Phone-Number-ID}/block_users

Get blocked users

- Guide: [Block Users](https://developers.facebook.com/docs/business-messaging/whatsapp/block-users)\n    \n- Endpoint reference: [GET WhatsApp Buiness Phone Number &gt; block_users](https://developers.facebook.com/docs/graph-api/reference/whats-app-business-account-to-number-current-status/block_users/#Reading)

### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |
| Content-Type | One of "application/json", "application/x-www-form-urlencoded", "multipart/form-data" | ✓ | Media type of the request body |

### Responses

**200**

Get blocked users

**Content Type**: `application/json`

**Schema**: [GetBlockedUsersData](#getblockedusersdata)


<jumplink id="post-version-phone-number-id-block-users"></jumplink>
## POST /{Version}/{Phone-Number-ID}/block_users

Block user(s)

- Guide: [Block Users](https://developers.facebook.com/docs/business-messaging/whatsapp/block-users)\n    \n- Endpoint reference: [POST WhatsApp Buiness Phone Number &gt; block_users](https://developers.facebook.com/docs/graph-api/reference/whats-app-business-account-to-number-current-status/block_users/#Creating)

### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |
| Content-Type | One of "application/json", "application/x-www-form-urlencoded", "multipart/form-data" | ✓ | Media type of the request body |

### Request Body (Optional)

**Content Type**: `application/json`

**Schema**: object

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| block_users | array of [Block_users](#object-block_users-1) |  |  |
| messaging_product | string |  |  |

### Responses

**200**

Block user(s)

**Content Type**: `application/json`

**Schema**: [BlockUsersData](#blockusersdata)


# Components

## Schemas

<jumplink id="blockeduser"></jumplink>
### BlockedUser

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| messaging_product | string |  |  |
| wa_id | string |  |  |

<jumplink id="paginationcursors"></jumplink>
### PaginationCursors

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| after | string |  |  |
| before | string |  |  |

<jumplink id="paging"></jumplink>
### Paging

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| cursors | [PaginationCursors](#paginationcursors) |  |  |

<jumplink id="getblockedusersdata"></jumplink>
### GetBlockedUsersData

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| data | array of [BlockedUser](#blockeduser) |  |  |
| paging | [Paging](#paging) |  |  |

<jumplink id="blockeduseroperation"></jumplink>
### BlockedUserOperation

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| input | string |  |  |
| wa_id | string |  |  |

<jumplink id="blockusersresult"></jumplink>
### BlockUsersResult

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| added_users | array of [BlockedUserOperation](#blockeduseroperation) |  |  |

<jumplink id="unblockusersresult"></jumplink>
### UnblockUsersResult

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| removed_users | array of [BlockedUserOperation](#blockeduseroperation) |  |  |

<jumplink id="blockusersdata"></jumplink>
### BlockUsersData

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| block_users | [BlockUsersResult](#blockusersresult) |  |  |
| messaging_product | string |  |  |

<jumplink id="unblockusersdata"></jumplink>
### UnblockUsersData

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| block_users | [UnblockUsersResult](#unblockusersresult) |  |  |
| messaging_product | string |  |  |

## Inline Object Definitions

<jumplink id="object-block_users-1"></jumplink>
### Block_users

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| user | string |  |  |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
