

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| POST | [/{Version}/{Solution-ID}/send_deactivation_request](#post-version-solution-id-send-deactivation-request) |

<jumplink id="post-version-solution-id-send-deactivation-request"></jumplink>
## POST /{Version}/{Solution-ID}/send_deactivation_request

Send Multi-Partner Solution Deactivation Request

Submit a deactivation request for a Multi-Partner Solution. This initiates
a workflow to transition the solution from its current state to deactivated,
following proper business validation and approval processes.


**Use Cases:**
- Request deactivation of an active Multi-Partner Solution
- Initiate solution lifecycle transition management
- Trigger business workflow for solution deactivation approval
- Programmatically manage solution lifecycle states


**Business Logic:**
- Solution must be in ACTIVE or INITIATED state to be eligible for deactivation
- Deactivation requests are processed asynchronously
- Solution status will transition to PENDING_DEACTIVATION during processing
- Final deactivation requires business approval workflow completion


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


**Workflow:**
1. Validate solution ownership and permissions
2. Check solution eligibility for deactivation
3. Submit deactivation request to business workflow
4. Return confirmation with tracking identifier


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| Solution-ID | string | ✓ | Your Multi-Partner Solution ID. This ID is provided when you create the solution and can be found in your Partner Dashboard or through solution management APIs. |

### Request Body (Optional)

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessSolutionDeactivationRequest](#whatsappbusinesssolutiondeactivationrequest)

### Responses

**200**

Successfully submitted deactivation request

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessSolutionDeactivationResponse](#whatsappbusinesssolutiondeactivationresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: solution_id must be a valid numeric string",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to request deactivation for this Multi-Partner Solution",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - Solution ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Multi-Partner Solution not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Solution is not eligible for deactivation

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Solution is not in a state that allows deactivation. Current status: DEACTIVATED",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinesssolutiondeactivationrequest"></jumplink>
### WhatsAppBusinessSolutionDeactivationRequest

Request payload for sending a Multi-Partner Solution deactivation request

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| reason | string |  | Optional reason for the deactivation request |

<jumplink id="whatsappbusinesssolutiondeactivationresponse"></jumplink>
### WhatsAppBusinessSolutionDeactivationResponse

Successful response for deactivation request submission

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| success | boolean | ✓ | Indicates whether the deactivation request was successfully submitted |
| message | string | ✓ | Human-readable message describing the result |
| request_id | string |  | Unique identifier for tracking the deactivation request |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-1) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-error-1"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
