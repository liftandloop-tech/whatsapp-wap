

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| POST | [/{Version}/{Solution-ID}/accept](#post-version-solution-id-accept) |

<jumplink id="post-version-solution-id-accept"></jumplink>
## POST /{Version}/{Solution-ID}/accept

Accept Multi-Partner Solution Invitation

Accept an invitation to participate in a Multi-Partner Solution as a partner application.
This endpoint transitions the partner's status from NOTIFICATION_SENT to ACCEPTED,
enabling the solution to progress toward ACTIVE status once all required partners accept.


**Use Cases:**
- Accept partnership invitations for Multi-Partner Solutions
- Activate partner participation in existing solutions
- Confirm partner app's commitment to solution terms and conditions
- Enable solution workflow progression from INITIATED to ACTIVE status


**Business Logic:**
- Only invited partner apps can accept solution invitations
- Solution must be in INITIATED status to accept partnerships
- Partner status transitions from NOTIFICATION_SENT to ACCEPTED
- Solution may become ACTIVE once all required partners accept
- Acceptance creates formal partnership agreement between apps


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


**Validation:**
- Partner app must have received a valid solution invitation
- Solution must exist and be accessible to the partner app
- Partner app must have proper permissions and capabilities
- Acceptance request must include valid partner app identification


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| Solution-ID | string | ✓ | ID of the Multi-Partner Solution to accept. This ID is provided in the original invitation and can be found in partner notifications or solution management interfaces. |

### Request Body (Required)

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessSolutionAcceptRequest](#whatsappbusinesssolutionacceptrequest)

### Responses

**200**

Multi-Partner Solution invitation accepted successfully. The partner's status has been
updated to ACCEPTED and the solution may progress toward ACTIVE status.


**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessSolutionAcceptResponse](#whatsappbusinesssolutionacceptresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: partner_app_id must be a valid numeric string",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or not invited to solution

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app is not invited to participate in this Multi-Partner Solution",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349175,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to accept this solution invitation"
    }
}\n```

**404**

Not Found - Solution ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Multi-Partner Solution not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Solution cannot be accepted in current state

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Solution cannot be accepted: solution is not in INITIATED status",
        "type": "GraphMethodException",
        "code": 100,
        "error_subcode": 2207051,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinesssolutionacceptrequest"></jumplink>
### WhatsAppBusinessSolutionAcceptRequest

Request payload for accepting a Multi-Partner Solution invitation

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| partner_app_id | string | ✓ | ID of the partner application accepting the solution invitation. This must match the app ID that received the original invitation. |
| log_session_id | string |  | Optional session identifier for logging and debugging purposes. Used to track the acceptance flow across multiple API calls. |

<jumplink id="whatsappbusinesssolutionacceptresponse"></jumplink>
### WhatsAppBusinessSolutionAcceptResponse

Successful response confirming solution acceptance

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| solution_id | string | ✓ | ID of the Multi-Partner Solution that was accepted |
| partner_status | [WhatsAppBusinessSolutionPartnerStatus](#whatsappbusinesssolutionpartnerstatus) | ✓ |  |
| success | boolean | ✓ | Indicates whether the acceptance was successful |
| message | string |  | Human-readable confirmation message |
| update_time | string (date-time) |  | Timestamp when the acceptance was processed |

<jumplink id="whatsappbusinesssolutionpartnerstatus"></jumplink>
### WhatsAppBusinessSolutionPartnerStatus

Current status of the partner's participation in the Multi-Partner Solution

**Type**: string

**Enum Values**: "DRAFT", "INITIATED", "NOTIFICATION_SENT", "ACCEPTED", "REJECTED", "DEACTIVATED"

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-1) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-error-1"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
