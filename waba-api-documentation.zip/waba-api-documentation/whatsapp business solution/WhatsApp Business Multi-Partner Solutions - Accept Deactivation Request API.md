

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Meta Graph API production server |

## APIs

| Method | Endpoint |
|--------|----------|
| POST | [/{Version}/{Solution-ID}/accept_deactivation_request](#post-version-solution-id-accept-deactivation-request) |

<jumplink id="post-version-solution-id-accept-deactivation-request"></jumplink>
## POST /{Version}/{Solution-ID}/accept_deactivation_request

Accept WhatsApp Business Solution Deactivation Request

Accepts a pending deactivation request for a WhatsApp Business Multi-Partner Solution.


This endpoint completes the partner approval workflow by accepting a deactivation request
that was previously initiated by another solution partner. Upon successful acceptance,
the solution status transitions from ACTIVE to DEACTIVATED, and the pending request
status changes from PENDING_DEACTIVATION to NONE.


**Important Business Logic:**

- Solution must be in ACTIVE status with PENDING_DEACTIVATION pending status

- All outstanding payments and invoices must be settled before acceptance

- Active marketing campaigns must be concluded or transferred

- Webhook notifications will be sent to all solution partners upon completion

- Solution resources and permissions will be cleaned up according to policy


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version |
| Solution-ID | string | ✓ | Unique identifier for the WhatsApp Business Solution |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| fields | string |  | Comma-separated list of fields to return in the response. **Available Fields:** id, name, status, status_for_pending_request, owner_permissions **Default Fields:** name, status, status_for_pending_request |

### Request Body (Optional)

Empty request body - no parameters required for this endpoint

**Content Type**: `application/json`

**Schema**: object

### Responses

**200**

Deactivation request accepted successfully. Solution status updated to DEACTIVATED.


**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessSolution](#whatsappbusinesssolution)

**Example**:\n```json\n{
    "id": "12345678901234567",
    "name": "Sample Business Solution Partnership",
    "status": "DEACTIVATED",
    "status_for_pending_request": "NONE",
    "owner_permissions": [
        "MANAGE",
        "DEVELOP"
    ]
}\n```

**400**

Bad Request - Invalid request parameters or malformed solution ID format.


**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid solution ID format provided",
        "type": "GraphAPIException",
        "code": 100,
        "error_subcode": 33,
        "fbtrace_id": "FAKE_TRACE_ID_12345",
        "is_transient": false,
        "error_user_title": "Invalid Request",
        "error_user_msg": "The solution ID format is not valid. Please check your request parameters."
    }
}\n```

**401**

Unauthorized - Invalid, missing, or expired access token.


**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "FAKE_TRACE_ID_67890",
        "is_transient": false,
        "error_user_title": "Authentication Required",
        "error_user_msg": "Please provide a valid access token to access this resource."
    }
}\n```

**403**

Forbidden - Insufficient permissions or app not authorized for this solution.


**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "App does not have permission to access this solution",
        "type": "GraphMethodException",
        "code": 10,
        "error_subcode": 2018218,
        "fbtrace_id": "FAKE_TRACE_ID_11111",
        "is_transient": false,
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app does not have the required permissions to perform this action on the solution."
    }
}\n```

**404**

Not Found - Solution ID does not exist or is not accessible to the requesting app.


**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Solution not found or not accessible",
        "type": "GraphMethodException",
        "code": 803,
        "error_subcode": 1675030,
        "fbtrace_id": "FAKE_TRACE_ID_22222",
        "is_transient": false,
        "error_user_title": "Resource Not Found",
        "error_user_msg": "The requested solution could not be found or you do not have access to it."
    }
}\n```

**422**

Unprocessable Entity - Valid parameters but business logic prevents processing (e.g., wrong solution state, outstanding payments).


**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Solution is not in a valid state to accept deactivation requests",
        "type": "GraphMethodException",
        "code": 100,
        "error_subcode": 2207013,
        "fbtrace_id": "FAKE_TRACE_ID_33333",
        "is_transient": false,
        "error_user_title": "Request Cannot Be Processed",
        "error_user_msg": "The solution must be in ACTIVE status with a pending deactivation request to accept deactivation."
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded. Use exponential backoff for retries.


**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "FAKE_TRACE_ID_44444",
        "is_transient": true,
        "error_user_title": "Rate Limit Exceeded",
        "error_user_msg": "Too many requests have been made. Please wait and try again later."
    }
}\n```

**500**

Internal Server Error - Unexpected server error. Retry with exponential backoff if is_transient is true.


**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred while processing your request",
        "type": "GraphAPIException",
        "code": 2,
        "error_subcode": 1349174,
        "fbtrace_id": "FAKE_TRACE_ID_55555",
        "is_transient": true,
        "error_user_title": "Service Temporarily Unavailable",
        "error_user_msg": "We're experiencing technical difficulties. Please try again in a few moments."
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinesssolution"></jumplink>
### WhatsAppBusinessSolution

WhatsApp Business Multi-Partner Solution object with core node fields only

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the WhatsApp Business Solution |
| name | string | ✓ | Human-readable name for the solution (UGC text, 2-75 characters) |
| status | [WhatsAppBusinessSolutionStatus](#whatsappbusinesssolutionstatus) | ✓ |  |
| status_for_pending_request | [WhatsAppBusinessSolutionPendingStatus](#whatsappbusinesssolutionpendingstatus) | ✓ |  |
| owner_permissions | array of [WhatsAppBusinessAccountPermissionTask](#whatsappbusinessaccountpermissiontask) |  | Array of permissions granted to the solution owner |

<jumplink id="whatsappbusinesssolutionstatus"></jumplink>
### WhatsAppBusinessSolutionStatus

Current status of the WhatsApp Business Solution

**Type**: string

**Enum Values**: "DRAFT", "INITIATED", "ACTIVE", "REJECTED", "DEACTIVATED", "PENDING_DEACTIVATION"

<jumplink id="whatsappbusinesssolutionpendingstatus"></jumplink>
### WhatsAppBusinessSolutionPendingStatus

Status of any pending requests for the solution

**Type**: string

**Enum Values**: "PENDING_ACTIVATION", "PENDING_DEACTIVATION", "NONE"

<jumplink id="whatsappbusinessaccountpermissiontask"></jumplink>
### WhatsAppBusinessAccountPermissionTask

Granular permission tasks for WhatsApp Business Account access

**Type**: string

**Enum Values**: "MANAGE", "DEVELOP", "MANAGE_TEMPLATES", "MANAGE_PHONE", "VIEW_COST", "MANAGE_EXTENSIONS", "VIEW_PHONE_ASSETS", "MANAGE_PHONE_ASSETS", "VIEW_TEMPLATES", "VIEW_INSIGHTS", "RECEIVE_INCOMING_MESSAGES", "MANAGE_BILLING", "MANAGE_USERS", "MESSAGING", "FULL_CONTROL"

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-1) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-error-1"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | One of "OAuthException", "GraphMethodException", "GraphAPIException" | ✓ | Error type classification |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode |
| fbtrace_id | string |  | Internal trace ID for debugging |
| is_transient | boolean |  | Whether this error might be resolved by retrying |
| error_user_title | string |  | User-friendly error title |
| error_user_msg | string |  | User-friendly error message |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
