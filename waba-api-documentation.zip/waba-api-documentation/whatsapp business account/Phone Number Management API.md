

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| GET | [/{Version}/{WABA-ID}/phone_numbers](#get-version-waba-id-phone-numbers) |
| POST | [/{Version}/{WABA-ID}/phone_numbers](#post-version-waba-id-phone-numbers) |

<jumplink id="get-version-waba-id-phone-numbers"></jumplink>
## GET /{Version}/{WABA-ID}/phone_numbers

Get WhatsApp Business Account Phone Numbers

Retrieve all phone numbers associated with a WhatsApp Business Account, including their
status, verification details, and configuration information.

**Use Cases:**
- List all phone numbers in a WhatsApp Business Account
- Monitor phone number status and verification progress
- Check phone number quality ratings and messaging limits
- Retrieve phone number configuration details

**Filtering:**
You can filter results using the `filtering` parameter with JSON-encoded filter conditions.
Supported filters include account_mode, messaging_limit_tier, and is_official_business_account.

**Sorting:**
Results can be sorted by creation_time or last_onboarded_time in ascending or descending order.

**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.

**Caching:**
Phone number data can be cached for short periods, but status information may change
frequently. Implement appropriate cache invalidation strategies.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WABA-ID | string | ✓ | WhatsApp Business Account ID. This ID can be found in your WhatsApp Manager or through the business management APIs. |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| fields | string |  | Comma-separated list of fields to include in the response. If not specified, default fields will be returned. Available fields include: id, display_phone_number, verified_name, status, quality_rating, country_code, country_dial_code, code_verification_status, unified_cert_status, account_mode, host_platform, messaging_limit_tier, is_official_business_account, username |
| filtering | string |  | JSON-encoded array of filter conditions. Each filter should specify field, operator, and value. Supported fields: account_mode, messaging_limit_tier, is_official_business_account |
| sort | One of "creation_time.asc", "creation_time.desc", "last_onboarded_time.asc", "last_onboarded_time.desc" |  | Sort field and direction. Format: field_name.asc or field_name.desc Supported fields: creation_time, last_onboarded_time |
| limit | integer [min: 1, max: 100] |  | Maximum number of phone numbers to return per page |
| after | string |  | Cursor for pagination - retrieve records after this cursor |
| before | string |  | Cursor for pagination - retrieve records before this cursor |

### Responses

**200**

Successfully retrieved WhatsApp Business Account phone numbers

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessAccountPhoneNumbersConnection](#whatsappbusinessaccountphonenumbersconnection)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: filtering must be valid JSON",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to access this WhatsApp Business Account",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - WhatsApp Business Account ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Account not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The requested fields are not available for this account",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


<jumplink id="post-version-waba-id-phone-numbers"></jumplink>
## POST /{Version}/{WABA-ID}/phone_numbers

Create WhatsApp Business Account Phone Number

Create a new phone number registration within a WhatsApp Business Account. This endpoint
initiates the phone number onboarding process, including verification and business name approval.

**Use Cases:**
- Add new phone numbers to a WhatsApp Business Account
- Migrate phone numbers from on-premises to Cloud API
- Register pre-verified phone numbers for BSP scenarios
- Initiate phone number verification and business name approval process

**Prerequisites:**
- WhatsApp Business Account must have available phone number slots
- Phone number must not be already registered with WhatsApp Business
- Business must meet WhatsApp Business API requirements
- Appropriate permissions and app review completion

**Process Flow:**
1. Submit phone number and business name for registration
2. Phone number verification code will be sent (if not pre-verified)
3. Business name will be submitted for review
4. Monitor status through GET endpoint until approval

**Rate Limiting:**
Phone number creation is subject to strict rate limits to prevent abuse.
Standard Graph API rate limits also apply.

**Migration Support:**
Set migrate_phone_number=true when migrating from on-premises API to Cloud API.
Additional validation and migration-specific logic will be applied.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WABA-ID | string | ✓ | WhatsApp Business Account ID where the phone number will be added. This ID can be found in your WhatsApp Manager or through business management APIs. |

### Request Body (Required)

**Content Type**: `application/json`

**Schema**: [PhoneNumberCreateRequest](#phonenumbercreaterequest)

### Responses

**200**

Successfully created phone number registration

**Content Type**: `application/json`

**Schema**: [PhoneNumberCreateResponse](#phonenumbercreateresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: phone_number must be in E.164 format",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or phone number limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Phone number limit exceeded for this WhatsApp Business Account",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349175,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Limit Exceeded",
        "error_user_msg": "You have reached the maximum number of phone numbers for this account"
    }
}\n```

**404**

Not Found - WhatsApp Business Account ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Account not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**409**

Conflict - Phone number already exists or is in use

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Phone number is already registered with WhatsApp Business",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Phone number validation failed: invalid format",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Phone number creation rate limit exceeded",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446080,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinessaccountphonenumber"></jumplink>
### WhatsAppBusinessAccountPhoneNumber

WhatsApp Business Account phone number details and status information

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the phone number status record |
| display_phone_number | string | ✓ | Phone number in international format for display purposes |
| verified_name | string |  | Business name verified for this phone number |
| status | [WhatsAppPhoneNumberStatus](#whatsappphonenumberstatus) | ✓ |  |
| quality_rating | [WhatsAppPhoneNumberQualityRating](#whatsappphonenumberqualityrating) |  |  |
| country_code | string |  | ISO 3166-1 alpha-2 country code |
| country_dial_code | string |  | Country dialing code |
| code_verification_status | [WhatsAppCodeVerificationStatus](#whatsappcodeverificationstatus) |  |  |
| unified_cert_status | [WhatsAppBusinessUnifiedCertStatus](#whatsappbusinessunifiedcertstatus) |  |  |
| account_mode | [WhatsAppBusinessSandboxEligibility](#whatsappbusinesssandboxeligibility) |  |  |
| host_platform | [WhatsAppBusinessAccountHostPlatform](#whatsappbusinessaccounthostplatform) |  |  |
| messaging_limit_tier | One of "TIER_50", "TIER_250", "TIER_1K", "TIER_10K", "TIER_100K", "TIER_UNLIMITED" |  | Current messaging limit tier for the phone number |
| is_official_business_account | boolean |  | Whether this is an official business account |
| username | string |  | WhatsApp username for the business account (if available) |

<jumplink id="whatsappphonenumberstatus"></jumplink>
### WhatsAppPhoneNumberStatus

Current status of the phone number in the WhatsApp Business Account

**Type**: string

**Enum Values**: "PENDING", "LINKED", "UNLINKED", "DELETED", "MIGRATED", "BANNED", "RESTRICTED"

<jumplink id="whatsappphonenumberqualityrating"></jumplink>
### WhatsAppPhoneNumberQualityRating

Quality rating for the phone number based on messaging patterns

**Type**: string

**Enum Values**: "GREEN", "YELLOW", "RED", "UNKNOWN"

<jumplink id="whatsappcodeverificationstatus"></jumplink>
### WhatsAppCodeVerificationStatus

Status of phone number verification code

**Type**: string

**Enum Values**: "VERIFIED", "NOT_VERIFIED"

<jumplink id="whatsappbusinessunifiedcertstatus"></jumplink>
### WhatsAppBusinessUnifiedCertStatus

Unified certification status combining business and name verification

**Type**: string

**Enum Values**: "APPROVED", "NAME_PENDING_REVIEW", "NAME_NOT_APPROVED", "ACCOUNT_REVIEW_NOT_STARTED", "LIMITED_ACCESS"

<jumplink id="whatsappbusinesssandboxeligibility"></jumplink>
### WhatsAppBusinessSandboxEligibility

Account mode indicating sandbox or live environment eligibility

**Type**: string

**Enum Values**: "LIVE", "SANDBOX"

<jumplink id="whatsappbusinessaccounthostplatform"></jumplink>
### WhatsAppBusinessAccountHostPlatform

Platform hosting the WhatsApp Business Account

**Type**: string

**Enum Values**: "CLOUD_API", "ON_PREMISE", "NOT_APPLICABLE"

<jumplink id="whatsappbusinessaccountphonenumbersconnection"></jumplink>
### WhatsAppBusinessAccountPhoneNumbersConnection

Paginated collection of WhatsApp Business Account phone numbers

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| data | array of [WhatsAppBusinessAccountPhoneNumber](#whatsappbusinessaccountphonenumber) | ✓ | Array of phone number records |
| paging | [CursorPaging](#cursorpaging) |  |  |

<jumplink id="cursorpaging"></jumplink>
### CursorPaging

Cursor-based pagination information

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| cursors | [Cursors](#object-cursors-1) |  |  |
| previous | string |  | URL for the previous page of results |
| next | string |  | URL for the next page of results |

<jumplink id="phonenumbercreaterequest"></jumplink>
### PhoneNumberCreateRequest

Request payload for creating a new phone number registration

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| phone_number | string | ✓ | Phone number in E.164 format without the + prefix |
| verified_name | string | ✓ | Business name to be verified for this phone number |
| cc | string |  | Country code for the phone number |
| migrate_phone_number | boolean |  | Whether this is a phone number migration from on-premises |
| preverified_id | string |  | Pre-verified phone number ID for BSP scenarios |

<jumplink id="phonenumbercreateresponse"></jumplink>
### PhoneNumberCreateResponse

Response after successfully creating a phone number registration

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the created phone number status record |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-2) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-cursors-1"></jumplink>
### Cursors

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| before | string |  | Cursor pointing to the start of the page |
| after | string |  | Cursor pointing to the end of the page |

<jumplink id="object-error-2"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
