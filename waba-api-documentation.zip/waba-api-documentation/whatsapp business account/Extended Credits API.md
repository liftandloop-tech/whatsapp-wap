

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com |  |

## APIs

| Method | Endpoint |
|--------|----------|
| GET | [/{Version}/{Business-ID}/extendedcredits](#get-version-business-id-extendedcredits) |

<jumplink id="get-version-business-id-extendedcredits"></jumplink>
## GET /{Version}/{Business-ID}/extendedcredits

Get credit lines

- Endpoint reference: [Business &gt; Extendedcredits](https://developers.facebook.com/docs/marketing-api/reference/extended-credit/)

### Responses

**200**

Example response

**Content Type**: `application/json`

**Schema**: object

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| data | array of [Data](#object-data-1) |  |  |


# Components

## Inline Object Definitions

<jumplink id="object-data-1"></jumplink>
### Data

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string |  |  |
| legal_entity_name | string |  |  |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
