

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| GET | [/{Version}/{WABA-ID}/schedules](#get-version-waba-id-schedules) |
| POST | [/{Version}/{WABA-ID}/schedules](#post-version-waba-id-schedules) |

<jumplink id="get-version-waba-id-schedules"></jumplink>
## GET /{Version}/{WABA-ID}/schedules

Get WhatsApp Business Account Schedules

Retrieve all schedules associated with a WhatsApp Business Account, including their
configuration, status, and execution details.

**Use Cases:**
- List all schedules in a WhatsApp Business Account
- Monitor schedule status and performance
- Check schedule configuration and timing details
- Retrieve schedule execution history and metrics

**Filtering:**
You can filter results using the `filtering` parameter with JSON-encoded filter conditions.
Supported filters include status, schedule_type, and is_active.

**Sorting:**
Results can be sorted by created_time or updated_time in ascending or descending order.

**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.

**Caching:**
Schedule data can be cached for short periods, but status information may change
frequently. Implement appropriate cache invalidation strategies.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WABA-ID | string | ✓ | WhatsApp Business Account ID. This ID can be found in your WhatsApp Manager or through the business management APIs. |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| fields | string |  | Comma-separated list of fields to include in the response. If not specified, default fields will be returned. Available fields include: id, name, status, schedule_type, description, start_time, end_time, timezone, days_of_week, created_time, updated_time, is_active, recurrence_pattern |
| filtering | string |  | JSON-encoded array of filter conditions. Each filter should specify field, operator, and value. Supported fields: status, schedule_type, is_active |
| sort | One of "created_time.asc", "created_time.desc", "updated_time.asc", "updated_time.desc" |  | Sort field and direction. Format: field_name.asc or field_name.desc Supported fields: created_time, updated_time |
| limit | integer [min: 1, max: 100] |  | Maximum number of schedules to return per page |
| after | string |  | Cursor for pagination - retrieve records after this cursor |
| before | string |  | Cursor for pagination - retrieve records before this cursor |

### Responses

**200**

Successfully retrieved WhatsApp Business Account schedules

**Content Type**: `application/json`

**Schema**: [WhatsAppBusinessAccountSchedulesConnection](#whatsappbusinessaccountschedulesconnection)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: filtering must be valid JSON",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to access this WhatsApp Business Account",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - WhatsApp Business Account ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Account not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The requested fields are not available for this account",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


<jumplink id="post-version-waba-id-schedules"></jumplink>
## POST /{Version}/{WABA-ID}/schedules

Create WhatsApp Business Account Schedule

Create a new schedule configuration within a WhatsApp Business Account. This endpoint
allows businesses to set up automated scheduling for various operations such as business hours,
automated responses, and maintenance windows.

**Use Cases:**
- Create business hours schedules for automated responses
- Set up maintenance windows for system operations
- Configure automated message campaigns with timing
- Establish recurring schedule patterns for business operations

**Prerequisites:**
- WhatsApp Business Account must have scheduling feature enabled
- Appropriate permissions for schedule management
- Valid timezone and time format specifications
- Business must meet WhatsApp Business API requirements

**Process Flow:**
1. Submit schedule configuration with timing and recurrence details
2. System validates schedule parameters and conflicts
3. Schedule is created and activated based on is_active flag
4. Monitor schedule status through GET endpoint

**Rate Limiting:**
Schedule creation is subject to rate limits to prevent abuse.
Standard Graph API rate limits also apply.

**Validation:**
- Start time must be before end time
- Timezone must be valid IANA timezone identifier
- Days of week must be valid if specified
- Recurrence pattern must be consistent with schedule type


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WABA-ID | string | ✓ | WhatsApp Business Account ID where the schedule will be created. This ID can be found in your WhatsApp Manager or through business management APIs. |

### Request Body (Required)

**Content Type**: `application/json`

**Schema**: [ScheduleCreateRequest](#schedulecreaterequest)

### Responses

**200**

Successfully created schedule

**Content Type**: `application/json`

**Schema**: [ScheduleCreateResponse](#schedulecreateresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: start_time must be before end_time",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or schedule limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Schedule limit exceeded for this WhatsApp Business Account",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349175,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Limit Exceeded",
        "error_user_msg": "You have reached the maximum number of schedules for this account"
    }
}\n```

**404**

Not Found - WhatsApp Business Account ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Account not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**409**

Conflict - Schedule name already exists or time conflict

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Schedule name already exists in this WhatsApp Business Account",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Schedule validation failed: invalid timezone identifier",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Schedule creation rate limit exceeded",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446080,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinessaccountschedule"></jumplink>
### WhatsAppBusinessAccountSchedule

WhatsApp Business Account schedule configuration and details

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the schedule |
| name | string | ✓ | Human-readable name for the schedule |
| status | [WhatsAppScheduleStatus](#whatsappschedulestatus) | ✓ |  |
| schedule_type | [WhatsAppScheduleType](#whatsappscheduletype) | ✓ |  |
| description | string |  | Optional description of the schedule purpose |
| start_time | string (time) |  | Schedule start time in HH:MM format |
| end_time | string (time) |  | Schedule end time in HH:MM format |
| timezone | string |  | Timezone identifier for the schedule |
| days_of_week | array of [DayOfWeek](#dayofweek) |  | Days of the week when the schedule is active |
| created_time | string (date-time) |  | ISO 8601 timestamp when the schedule was created |
| updated_time | string (date-time) |  | ISO 8601 timestamp when the schedule was last updated |
| is_active | boolean |  | Whether the schedule is currently active |
| recurrence_pattern | [RecurrencePattern](#recurrencepattern) |  |  |

<jumplink id="whatsappschedulestatus"></jumplink>
### WhatsAppScheduleStatus

Current status of the schedule

**Type**: string

**Enum Values**: "ACTIVE", "INACTIVE", "PAUSED", "EXPIRED", "DRAFT"

<jumplink id="whatsappscheduletype"></jumplink>
### WhatsAppScheduleType

Type of schedule configuration

**Type**: string

**Enum Values**: "BUSINESS_HOURS", "AUTOMATED_RESPONSE", "MESSAGE_CAMPAIGN", "MAINTENANCE_WINDOW", "CUSTOM"

<jumplink id="dayofweek"></jumplink>
### DayOfWeek

Day of the week

**Type**: string

**Enum Values**: "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"

<jumplink id="recurrencepattern"></jumplink>
### RecurrencePattern

Pattern for recurring schedules

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| frequency | One of "DAILY", "WEEKLY", "MONTHLY", "YEARLY" |  |  |
| interval | integer [min: 1] |  | Interval between recurrences |
| end_date | string (date) |  | End date for the recurrence pattern |

<jumplink id="whatsappbusinessaccountschedulesconnection"></jumplink>
### WhatsAppBusinessAccountSchedulesConnection

Paginated collection of WhatsApp Business Account schedules

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| data | array of [WhatsAppBusinessAccountSchedule](#whatsappbusinessaccountschedule) | ✓ | Array of schedule records |
| paging | [CursorPaging](#cursorpaging) |  |  |

<jumplink id="cursorpaging"></jumplink>
### CursorPaging

Cursor-based pagination information

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| cursors | [Cursors](#object-cursors-1) |  |  |
| previous | string |  | URL for the previous page of results |
| next | string |  | URL for the next page of results |

<jumplink id="schedulecreaterequest"></jumplink>
### ScheduleCreateRequest

Request payload for creating a new schedule

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| name | string | ✓ | Human-readable name for the schedule |
| schedule_type | [WhatsAppScheduleType](#whatsappscheduletype) | ✓ |  |
| description | string |  | Optional description of the schedule purpose |
| start_time | string (time) | ✓ | Schedule start time in HH:MM format |
| end_time | string (time) | ✓ | Schedule end time in HH:MM format |
| timezone | string |  | Timezone identifier for the schedule |
| days_of_week | array of [DayOfWeek](#dayofweek) |  | Days of the week when the schedule is active |
| is_active | boolean |  | Whether the schedule should be active upon creation |
| recurrence_pattern | [RecurrencePattern](#recurrencepattern) |  |  |

<jumplink id="schedulecreateresponse"></jumplink>
### ScheduleCreateResponse

Response after successfully creating a schedule

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the created schedule |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-2) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-cursors-1"></jumplink>
### Cursors

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| before | string |  | Cursor pointing to the start of the page |
| after | string |  | Cursor pointing to the end of the page |

<jumplink id="object-error-2"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
