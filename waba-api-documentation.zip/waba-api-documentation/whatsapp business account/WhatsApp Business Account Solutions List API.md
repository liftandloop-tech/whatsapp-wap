

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| GET | [/{Version}/{WABA-ID}/solutions](#get-version-waba-id-solutions) |

<jumplink id="get-version-waba-id-solutions"></jumplink>
## GET /{Version}/{WABA-ID}/solutions

List Multi-Partner Solutions for WABA

Retrieve a paginated list of Multi-Partner Solutions associated with the specified
WhatsApp Business Account. This endpoint supports field selection and cursor-based
pagination for efficient data retrieval.


**Use Cases:**
- Discover available Multi-Partner Solutions for business onboarding
- Monitor solution status and availability across your WABA
- Retrieve solution ownership and permission details
- Filter solutions by specific fields or status requirements


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


**Caching:**
Solution listings can be cached for short periods, but status information may change
frequently during transitions. Implement appropriate cache invalidation strategies.


**Pagination:**
This endpoint supports cursor-based pagination using `limit`, `after`, and `before`
parameters. Use the `paging` object in responses to navigate through result sets.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WABA-ID | string | ✓ | WhatsApp Business Account ID for which to retrieve associated Multi-Partner Solutions. This ID can be found in your WhatsApp Business Manager or through WABA management APIs. |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| fields | string |  | Comma-separated list of fields to include in the response. If not specified, default fields will be returned (name, status, status_for_pending_request). Available fields: id, name, status, status_for_pending_request, owner_app, owner_permissions |
| limit | integer [min: 1, max: 100] |  | Maximum number of solutions to return per page. Default is 25, maximum is 100. |
| after | string |  | Cursor for pagination. Returns solutions after this cursor position. Use the cursor from the previous response's `paging.cursors.after` field. |
| before | string |  | Cursor for pagination. Returns solutions before this cursor position. Use the cursor from the previous response's `paging.cursors.before` field. |

### Responses

**200**

Successfully retrieved Multi-Partner Solutions list

**Content Type**: `application/json`

**Schema**: [SolutionsList](#solutionslist)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: waba_id must be a valid numeric string",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "FAKE_TRACE_ID_123ABC456DEF"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "FAKE_TRACE_ID_123ABC456DEF"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to access this WhatsApp Business Account",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "FAKE_TRACE_ID_123ABC456DEF",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - WABA ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Account not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "FAKE_TRACE_ID_123ABC456DEF"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The requested fields are not available for this WABA",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "FAKE_TRACE_ID_123ABC456DEF"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "FAKE_TRACE_ID_123ABC456DEF",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "FAKE_TRACE_ID_123ABC456DEF",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="whatsappbusinesssolution"></jumplink>
### WhatsAppBusinessSolution

Multi-Partner Solution details and configuration

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the Multi-Partner Solution |
| name | string | ✓ | Human-readable name of the Multi-Partner Solution |
| status | [WhatsAppBusinessSolutionStatus](#whatsappbusinesssolutionstatus) | ✓ |  |
| status_for_pending_request | [WhatsAppBusinessSolutionPendingStatus](#whatsappbusinesssolutionpendingstatus) | ✓ |  |
| owner_app | [ApplicationNode](#applicationnode) |  |  |
| owner_permissions | array of [WhatsAppBusinessAccountPermissionTask](#whatsappbusinessaccountpermissiontask) |  | List of WhatsApp Business Account permissions granted to the solution owner |

<jumplink id="whatsappbusinesssolutionstatus"></jumplink>
### WhatsAppBusinessSolutionStatus

Current effective status of the Multi-Partner Solution

**Type**: string

**Enum Values**: "DRAFT", "INITIATED", "ACTIVE", "REJECTED", "DEACTIVATED"

<jumplink id="whatsappbusinesssolutionpendingstatus"></jumplink>
### WhatsAppBusinessSolutionPendingStatus

Status of any pending solution status transition requests

**Type**: string

**Enum Values**: "PENDING_ACTIVATION", "PENDING_DEACTIVATION", "NONE"

<jumplink id="whatsappbusinessaccountpermissiontask"></jumplink>
### WhatsAppBusinessAccountPermissionTask

Granular permission tasks for WhatsApp Business Account access

**Type**: string

**Enum Values**: "MANAGE", "DEVELOP", "MANAGE_TEMPLATES", "MANAGE_PHONE", "VIEW_COST", "MANAGE_EXTENSIONS", "VIEW_PHONE_ASSETS", "MANAGE_PHONE_ASSETS", "VIEW_TEMPLATES", "VIEW_INSIGHTS", "RECEIVE_INCOMING_MESSAGES", "MANAGE_BILLING", "MANAGE_USERS", "MESSAGING", "FULL_CONTROL"

<jumplink id="applicationnode"></jumplink>
### ApplicationNode

Meta application that owns the Multi-Partner Solution

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string |  | Unique identifier for the Meta application |
| name | string |  | Name of the Meta application |

<jumplink id="solutionslist"></jumplink>
### SolutionsList

Paginated list of Multi-Partner Solutions

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| data | array of [WhatsAppBusinessSolution](#whatsappbusinesssolution) | ✓ | Array of Multi-Partner Solutions associated with the WABA |
| paging | [Paging](#paging) |  |  |

<jumplink id="paging"></jumplink>
### Paging

Pagination information for cursor-based pagination

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| cursors | [Cursors](#object-cursors-1) |  |  |
| previous | string |  | Graph API endpoint URL for the previous page of data |
| next | string |  | Graph API endpoint URL for the next page of data |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-2) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-cursors-1"></jumplink>
### Cursors

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| before | string |  | Cursor pointing to the start of the page of data that has been returned |
| after | string |  | Cursor pointing to the end of the page of data that has been returned |

<jumplink id="object-error-2"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
