

## Base URL

| URL | Description |
|-----|-------------|
| https://graph.facebook.com | Production Graph API server |

## APIs

| Method | Endpoint |
|--------|----------|
| DELETE | [/{Version}/{WhatsApp-Business-Account-ID}/assigned_users](#delete-version-whatsapp-business-account-id-assigned-users) |
| GET | [/{Version}/{WhatsApp-Business-Account-ID}/assigned_users](#get-version-whatsapp-business-account-id-assigned-users) |
| POST | [/{Version}/{WhatsApp-Business-Account-ID}/assigned_users](#post-version-whatsapp-business-account-id-assigned-users) |

<jumplink id="delete-version-whatsapp-business-account-id-assigned-users"></jumplink>
## DELETE /{Version}/{WhatsApp-Business-Account-ID}/assigned_users

Remove User from WhatsApp Business Account

Remove a user's access from the WhatsApp Business Account. This operation revokes
all permissions and access rights for the specified user on the account.


**Use Cases:**
- Revoke user access when they leave the organization
- Remove temporary access grants
- Clean up user permissions for security compliance
- Manage user lifecycle and access control


**Important Notes:**
- This operation removes ALL permissions for the user on this WhatsApp Business Account
- The user will lose access to all account features and data
- This action cannot be undone - the user must be re-added if access is needed again
- Webhooks may be triggered to notify of user access changes


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WhatsApp-Business-Account-ID | string | ✓ | Your WhatsApp Business Account ID. This ID is provided when you create the account and can be found in your Business Manager or through account management APIs. |

### Request Body (Required)

**Content Type**: `application/x-www-form-urlencoded`

**Schema**: object

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| user | string | ✓ | User ID of the person to remove from the WhatsApp Business Account. This must be a valid Facebook user ID that is currently assigned to the account. |

### Responses

**200**

Successfully removed user from WhatsApp Business Account

**Content Type**: `application/json`

**Schema**: [SuccessResponse](#successresponse)

**Example**:\n```json\n{
    "success": true
}\n```

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: user must be a valid user ID",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to remove users from this WhatsApp Business Account",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - WhatsApp Business Account ID or User ID does not exist or is not assigned

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "User is not assigned to this WhatsApp Business Account",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Cannot remove user due to business asset group permissions",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


<jumplink id="get-version-whatsapp-business-account-id-assigned-users"></jumplink>
## GET /{Version}/{WhatsApp-Business-Account-ID}/assigned_users

List Assigned Users

Retrieve a list of users assigned to the WhatsApp Business Account with their permissions
and user details. This endpoint supports pagination and filtering capabilities.


**Use Cases:**
- Audit user access to WhatsApp Business Account
- Retrieve user permission assignments for compliance
- List all users with access for management purposes
- Monitor user access patterns and assignments


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


**Caching:**
User assignment data can be cached for short periods, but permission changes may occur
frequently. Implement appropriate cache invalidation strategies.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WhatsApp-Business-Account-ID | string | ✓ | Your WhatsApp Business Account ID. This ID is provided when you create the account and can be found in your Business Manager or through account management APIs. |

### Query Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| business | string | ✓ | Business ID that owns or has access to the WhatsApp Business Account. This parameter is required to specify the business context for user assignments. |
| fields | string |  | Comma-separated list of fields to include in the response. If not specified, default fields will be returned (id, name). Available fields: id, name, business, user_type |
| limit | integer [min: 1, max: 100] |  | Maximum number of assigned users to return per page. Default is 25, maximum is 100. |
| after | string |  | Cursor for pagination. Use this to get the next page of results. |
| before | string |  | Cursor for pagination. Use this to get the previous page of results. |

### Responses

**200**

Successfully retrieved assigned users list

**Content Type**: `application/json`

**Schema**: [AssignedUsersResponse](#assignedusersresponse)

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The parameter business is required to specify a business",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Need permission on WhatsAppBusinessAccount or this Business",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - WhatsApp Business Account ID does not exist or is not accessible

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Account not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "The requested fields are not available for this account",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


<jumplink id="post-version-whatsapp-business-account-id-assigned-users"></jumplink>
## POST /{Version}/{WhatsApp-Business-Account-ID}/assigned_users

Add User to WhatsApp Business Account

Add a user to the WhatsApp Business Account with specified permission tasks.
This operation grants the user access to perform specific actions on the account
based on the provided permission tasks.


**Use Cases:**
- Grant user access to WhatsApp Business Account management
- Assign specific permission tasks for granular access control
- Add new team members to WhatsApp Business Account operations
- Configure user permissions for different business roles


**Permission Tasks:**
Different permission tasks grant access to different WhatsApp Business Account features:
- MANAGE: General account management permissions
- DEVELOP: Development and API access permissions
- MANAGE_TEMPLATES: Message template management
- MANAGE_PHONE: Phone number management
- MESSAGING: Send and receive messages
- FULL_CONTROL: Complete access to all account features


**Rate Limiting:**
Standard Graph API rate limits apply. Use appropriate retry logic with exponential backoff.


### Header Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| User-Agent | string |  | The user agent string identifying the client software making the request. |
| Authorization | string | ✓ | Bearer token for API authentication. This should be a valid access token obtained through the appropriate OAuth flow or system user token. |

### Path Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| Version | string | ✓ | Graph API version to use for this request. Determines the API behavior and available features. |
| WhatsApp-Business-Account-ID | string | ✓ | Your WhatsApp Business Account ID. This ID is provided when you create the account and can be found in your Business Manager or through account management APIs. |

### Request Body (Required)

**Content Type**: `application/x-www-form-urlencoded`

**Schema**: object

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| user | string | ✓ | User ID of the person to add to the WhatsApp Business Account. This must be a valid Facebook user ID. |
| tasks | array of [WhatsAppBusinessAccountPermissionTask](#whatsappbusinessaccountpermissiontask) | ✓ | Array of permission tasks to grant to the user. These tasks determine what actions the user can perform on the WhatsApp Business Account. |

### Responses

**200**

Successfully added user to WhatsApp Business Account

**Content Type**: `application/json`

**Schema**: [SuccessResponse](#successresponse)

**Example**:\n```json\n{
    "success": true
}\n```

**400**

Bad Request - Invalid parameters or malformed request

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid parameter: user must be a valid user ID",
        "type": "OAuthException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**401**

Unauthorized - Invalid or missing access token

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Invalid OAuth access token",
        "type": "OAuthException",
        "code": 190,
        "error_subcode": 463,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**403**

Forbidden - Insufficient permissions or access denied

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Your app doesn't have permission to add users to this WhatsApp Business Account",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 1349174,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "error_user_title": "Permission Denied",
        "error_user_msg": "Your app doesn't have permission to access this resource"
    }
}\n```

**404**

Not Found - WhatsApp Business Account ID or User ID does not exist

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "WhatsApp Business Account not found",
        "type": "GraphMethodException",
        "code": 803,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**422**

Unprocessable Entity - Request parameters are valid but cannot be processed

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "User is already assigned to this WhatsApp Business Account",
        "type": "GraphMethodException",
        "code": 100,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn"
    }
}\n```

**429**

Too Many Requests - Rate limit exceeded

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "Application request limit reached",
        "type": "OAuthException",
        "code": 4,
        "error_subcode": 2446079,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```

**500**

Internal Server Error - Unexpected server error

**Content Type**: `application/json`

**Schema**: [GraphAPIError](#graphapierror)

**Example**:\n```json\n{
    "error": {
        "message": "An unexpected error occurred. Please retry your request",
        "type": "GraphMethodException",
        "code": 2,
        "fbtrace_id": "AXsgnV2Cm3ZMGF3dF_cfYIn",
        "is_transient": true
    }
}\n```


# Components

## Schemas

<jumplink id="assigneduser"></jumplink>
### AssignedUser

User assigned to WhatsApp Business Account with permissions

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string | ✓ | Unique identifier for the assigned user |
| name | string | ✓ | Display name of the assigned user |
| business | [BusinessNode](#businessnode) |  |  |
| user_type | [AssignedUserType](#assignedusertype) |  |  |

<jumplink id="assignedusertype"></jumplink>
### AssignedUserType

Type of user assignment

**Type**: string

**Enum Values**: "BUSINESS_USER", "SYSTEM_USER", "PERSONAL_USER"

<jumplink id="businessnode"></jumplink>
### BusinessNode

Business entity associated with the user

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| id | string |  | Unique identifier for the business |
| name | string |  | Name of the business |

<jumplink id="whatsappbusinessaccountpermissiontask"></jumplink>
### WhatsAppBusinessAccountPermissionTask

Granular permission tasks for WhatsApp Business Account access

**Type**: string

**Enum Values**: "MANAGE", "DEVELOP", "MANAGE_TEMPLATES", "MANAGE_PHONE", "VIEW_COST", "MANAGE_EXTENSIONS", "VIEW_PHONE_ASSETS", "MANAGE_PHONE_ASSETS", "VIEW_TEMPLATES", "VIEW_INSIGHTS", "RECEIVE_INCOMING_MESSAGES", "MANAGE_BILLING", "MANAGE_USERS", "MESSAGING", "FULL_CONTROL"

<jumplink id="assignedusersresponse"></jumplink>
### AssignedUsersResponse

Response containing list of assigned users with pagination

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| data | array of [AssignedUser](#assigneduser) | ✓ | Array of assigned users |
| paging | [CursorPaging](#cursorpaging) |  |  |
| summary | [AssignedUsersSummary](#assigneduserssummary) |  |  |

<jumplink id="assigneduserssummary"></jumplink>
### AssignedUsersSummary

Summary information about assigned users

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| total_count | integer |  | Total number of assigned users |

<jumplink id="cursorpaging"></jumplink>
### CursorPaging

Cursor-based pagination information

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| cursors | [Cursors](#object-cursors-1) |  |  |
| next | string |  | Graph API endpoint for the next page of results |
| previous | string |  | Graph API endpoint for the previous page of results |

<jumplink id="successresponse"></jumplink>
### SuccessResponse

Standard success response for write operations

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| success | boolean | ✓ | Indicates whether the operation was successful |

<jumplink id="graphapierror"></jumplink>
### GraphAPIError

Standard Graph API error response

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| error | [Error](#object-error-2) | ✓ |  |

## Inline Object Definitions

<jumplink id="object-cursors-1"></jumplink>
### Cursors

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| before | string |  | Cursor pointing to the start of the page of data |
| after | string |  | Cursor pointing to the end of the page of data |

<jumplink id="object-error-2"></jumplink>
### Error

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| message | string | ✓ | Human-readable error message |
| type | string | ✓ | Error category type |
| code | integer | ✓ | Numeric error code |
| error_subcode | integer |  | More specific error subcode when available |
| fbtrace_id | string |  | Unique identifier for debugging and support requests with Meta |
| is_transient | boolean |  | Indicates whether this error is temporary and the request should be retried |
| error_user_title | string |  | User-friendly error title for display purposes |
| error_user_msg | string |  | User-friendly error message for display purposes |

## Authentication

| Scheme | Type | Location |
|--------|------|----------|
| bearerAuth | HTTP Bearer | Header: `Authorization` |

### Usage Examples

- **bearerAuth**: Include `Authorization: Bearer your-token-here` in request headers

### Global Authentication Requirements

All endpoints require: bearerAuth
