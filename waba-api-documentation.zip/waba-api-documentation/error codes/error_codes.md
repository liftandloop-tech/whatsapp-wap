# WhatsApp Business Cloud API Error Codes

This document provides a comprehensive list of error codes for the WhatsApp Business Cloud API, including handling synchronous and asynchronous errors.

## Content Overview
- [Error Response Format](#error-response-format)
- [Authorization Errors](#authorization-errors)
- [Integrity Errors](#integrity-errors)
- [Template Creation Errors](#template-creation-errors)
- [Send Template Errors](#send-template-errors)
- [Phone Migration Errors](#phone-migration-errors)
- [Template Insights Errors](#template-insights-errors)
- [WhatsApp Business Account Errors](#whatsapp-business-account-errors)
- [Synchronization Errors](#synchronization-errors)
- [Throttling Errors](#throttling-errors)
- [Other Errors](#other-errors)
- [Marketing Messages API Exclusive Errors](#marketing-messages-api-exclusive-errors)

---

## Error Response Format

Cloud API errors are returned either synchronously as a Graph API response, asynchronously via Webhook, or sometimes through both methods.

### Syntax
```json
{
  "error": {
    "message": "<MESSAGE>",
    "type": "<TYPE>",
    "code": <CODE>,
    "error_data": {
      "messaging_product": "whatsapp",
      "details": "<DETAILS>"
    },
    "error_subcode": <ERROR_SUBCODE>,
    "fbtrace_id": "<FBTRACE_ID>"
  }
}
```

### Property Descriptions
| Property | Type | Description |
| :------- | :--- | :---------- |
| **code** | Integer | Error code. Build your app’s error handling around these instead of subcodes or HTTP status codes. |
| **details** | String | Description of the most likely reason for the error and potential solutions. |
| **error_subcode** | Integer | Deprecated. Will not be returned in v16.0+ responses. |
| **fbtrace_id** | String | Trace ID to include when contacting Direct Support for debugging. |
| **message** | String | Combination of the error code and its title (e.g., `(#130429) Rate limit hit`). |
| **messaging_product** | String | Always the string `whatsapp` for Cloud API responses. |
| **type** | String | Error type (e.g., `OAuthException`). |

---

## Authorization Errors

| Code | Details | Possible Reasons and Solutions | HTTP Status |
| :--- | :------ | :----------------------------- | :---------- |
| **0** | AuthException | Unable to authenticate. The access token might be expired, invalidated, or the app user changed settings. | 401 |
| **3** | API Method | Capability or permissions issue. Verify required permissions using the access token debugger. | 500 |
| **10** | Permission Denied | Permission not granted or removed. Check eligibility and phone number allowlisting for Flows. | 403 |
| **190** | Access token expired | Your access token has expired. Get a new access token. | 401 |
| **200-299** | API Permission | Permission not granted or removed. Verify via access token debugger. | 403 |

---

## Integrity Errors

| Code | Details | Possible Reasons and Solutions | HTTP Status |
| :--- | :------ | :----------------------------- | :---------- |
| **368** | Temporarily blocked | Restricted/disabled for violating a platform policy. | 403 |
| **130497** | Regional Restriction | Business account restricted from messaging users in certain countries. | 403 |
| **131031** | Account Locked | Violation of platform policy or verification failure (e.g., incorrect two-step PIN). | 403 |

---

## Template Creation Errors

| Error | Description | Possible Solution |
| :---- | :---------- | :---------------- |
| **2388040** | Character limit exceeded | A field exceeded maximum character limits. Refer to error message for details. |
| **2388047** | Header format incorrect | Invalid header formatting. |
| **2388072** | Body format incorrect | Invalid message body formatting. |
| **2388073** | Footer format incorrect | Invalid message footer formatting. |
| **2388293** | Variable ratio too high | Too many variables for the length. Reduce variables or increase text length. |
| **2388299** | Boundary parameters | Variables cannot be at the start or end of the template. |

---

## Send Template Errors

| Error | Description | Possible Solution |
| :---- | :---------- | :---------------- |
| **2388019** | Limit Exceeded | Exceeded maximum templates (limit is 250). |

---

## Phone Migration Errors

| Error | Description | Possible Solution |
| :---- | :---------- | :---------------- |
| **2388012** | Number exists | Phone number already present in your WhatsApp account. |
| **2388091/93** | Ineligible for verification | Ownership verification APIs are not available for this case. Register/verify the number manually. |
| **2388103** | Webhooks not set | Ensure webhooks are set up for the destination WABA. |
| **2388103** | Direct Add eligible | Number can be added directly, doesn't need migration APIs. |
| **2388103** | Approved name required | Display name must be APPROVED with no pending changes. |
| **2388103** | Source setup error | Source WABA must be approved and "messaging on behalf of" approved. |
| **2388103** | Missing credit line | Destination account must have an active credit line for post-migration messaging. |
| **2388103** | Generic migration error | Something went wrong. Retry later or contact support. |
| **2388103** | BM mismatch | Source and destination WABAs must represent the same business. |
| **2388103** | Destination not approved | Destination WABA must be approved before migration. |
| **2388103** | Client approval | Destination WABA “Messaging For” request must be approved by the client. |
| **2494100** | Maintenance mode | Phone number is in maintenance. Try again in a few minutes. |

---

## Template Insights Errors

| Error | Description | Possible Solution |
| :---- | :---------- | :---------------- |
| **200005** | Insights unavailable | Insights not yet available for this WABA. |
| **200006** | Cannot disable | Once enabled, template insights cannot be disabled. |
| **200007** | Not enabled | Template Insights have not been enabled for this account. |

---

## WhatsApp Business Account Errors

| Error | Description | Possible Solution |
| :---- | :---------- | :---------------- |
| **2593079** | Migration pending | Already marked for migration to a different solution ID. |
| **2593085** | Transfer Ineligible | Not eligible for OBO transfer. Possible reasons: already shared or client hasn't accepted request. |

---

## Synchronization Errors

| Code | Details | Possible Reasons and Solutions | HTTP Status |
| :--- | :------ | :----------------------------- | :---------- |
| **2593107** | Limit exceeded | Max calls for synchronization API reached for this number. | 400 |
| **2593108** | Stale request | Request must be made within 24 hours of onboarding. | 400 |

---

## Throttling Errors

| Code | Details | Possible Reasons and Solutions | HTTP Status |
| :--- | :------ | :----------------------------- | :---------- |
| **4** | App Rate Limit | App reached its rate limit. Check App Dashboard. | 400 |
| **80007** | WABA Rate Limit | WABA reached its rate limit. | 400 |
| **130429** | Cloud API throughput | Message throughput limit reached. Reduce frequency. | 400 |
| **131048** | Spam rate limit | Restrictions due to too many messages being flagged as spam. | 400 |
| **131056** | Recipient pair limit | Too many messages sent to the same recipient in a short period. | 400 |
| **133016** | Registration limit | Reached registration/deregistration attempt limit. | 400 |

---

## Other Errors

| Code | Details | Possible Reasons and Solutions | HTTP Status |
| :--- | :------ | :----------------------------- | :---------- |
| **1** | API Unknown | Invalid request or server error. Check status page. | 400 |
| **2** | API Service | Downtime or overload. Check status page. | 503 |
| **33** | Invalid Number | The business phone number has been deleted. | 400 |
| **100** | Invalid parameter | Unsupported or misspelled parameters. Check RSA key format for Flows. | 400 |
| **130472** | Experiment active | Message not sent as part of a marketing experiment. | 400 |
| **131000** | Generic error | Unknown error. Retry or open support ticket. | 500 |
| **131005** | Access denied | Permissions missing. Use access token debugger. | 403 |
| **131008** | Missing parameter | Required parameter is missing. Check documentation. | 400 |
| **131009** | Invalid value | Parameter values are invalid. Check Phone Numbers setup. | 400 |
| **131016** | Service unavailable | Service temporarily unavailable. | 500 |
| **131021** | Self-messaging | Sender and recipient phone numbers are the same. | 400 |
| **131026** | Undeliverable | Recipient not on WA, hasn't accepted terms, or uses old version. | 400 |
| **131037** | Name approval req. | Display name needs approval before sending. | 400 |
| **131042** | Payment issue | Credit line over limit, not attached, or account suspended. | 400 |
| **131045** | Incorrect certificate | Registration error. Re-register the number. | 500 |
| **131047** | 24-hour window | Over 24h since last user reply. Use a template. | 400 |
| **131049** | Delivery refusal | Meta chose not to deliver to maintain ecosystem health. | 400 |
| **131050** | User Opt-out | Recipient has stopped receiving marketing messages from you. | 400 |
| **131051** | Unsupported type | Check supported message types. | 400 |
| **131052** | Download failure | Unable to download media sent by user. | 400 |
| **131053** | Upload failure | Unable to upload media (check MIME type/size). | 400 |
| **131057** | Maintenance | WABA in maintenance mode (possible upgrade in progress). | 500 |
| **132000** | Param count mismatch | Mismatch between request params and template definition. | 400 |
| **132001** | Template not found | Template missing, not approved, or localized wrongly. | 404 |
| **132005** | Text too long | Hydrated text exceeds limits. | 400 |
| **132007** | Policy violation | Template content violates WhatsApp policy. | 400 |
| **132012** | Format mismatch | Param values don't match template definition formats. | 400 |
| **132015** | Template Paused | Paused due to low quality. Edit to improve. | 400 |
| **132016** | Template Disabled | Permanently disabled due to repeated low quality. | 400 |
| **132068** | Flow blocked | Flow is in a blocked state. Correct the Flow. | 400 |
| **132069** | Flow throttled | Throttled state reached. | 400 |
| **133000** | Incomplete dereg. | Previous deregistration failed. | 500 |
| **133004** | Server unavailable | Service temporarily unavailable. | 503 |
| **133005** | PIN Mismatch | Two-step verification PIN is incorrect. | 400 |
| **133006** | Re-verify needed | Phone number needs verification before registration. | 400 |
| **133008** | Too many guesses | Too many PIN guesses. Wait before retrying. | 400 |
| **133009** | PIN entered too fast | Wait before retrying. | 400 |
| **133010** | Not Registered | Number not registered on WhatsApp Business Platform. | 400 |
| **133015** | Deletion in progress | Wait 5 minutes after deleting before re-trying registration. | 400 |
| **134011** | Payments terms req. | Accept WhatsApp Payments terms of service. | 400 |
| **135000** | Parameter syntax | Unknown error with request parameters. Check syntax. | 400 |

---

## Marketing Messages API Exclusive Errors

| Code | Message | Details | Possible Solution | HTTP Status |
| :--- | :------ | :------ | :---------------- | :---------- |
| **100** | Invalid parameter | Message must be a template. | Type must be a marketing template. | 400 |
| **131009** | Invalid param value | One or more values invalid. | Verify params or wait 10m for ad syncing. | 400 |
| **131055** | Method not allowed | Only marketing templates supported. | Utility/Auth templates not allowed here. | 400 |
| **134100** | Only marketing supported | Utility/Auth templates not allowed. | Only MARKETING cateogry supported. | 400 |
| **134101** | Template syncing | Creation sync can take 10 minutes. | Wait and try again. | 400 |
| **134102** | Template unavailable | Ad synchronization failed or ineligible. | Check `marketing_messages_lite_api_status`. | 500 |
| **132018** | Validation error | Issue with template parameters. | Resend with correct configuration. | 400 |
| **1752041** | Duplicate Request | Client already invited to onboard. | All eligible WABAs will be onboarded automatically. | 400 |
